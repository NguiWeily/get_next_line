/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils_bonus.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/20 15:33:07 by wngui             #+#    #+#             */
/*   Updated: 2023/09/20 15:33:19 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line_bonus.h" // Include the header file that declares the functions and constants used in this code.

// Function to calculate the length of a string.
size_t	ft_strlen(const char *s)
{
	size_t	len; // Variable to store the length of the string.

	len = 0;
	while (s[len]) // Iterate through the characters of the string until the null terminator.
		len++;
	return (len); // Return the length of the string.
}

// Function to set 'n' bytes of memory to zero.
void	ft_bzero(void *s, size_t n)
{
	while (n--)
		*(char *)s++ = 0; // Iterate through 'n' bytes and set each byte to zero.
}

// Function to copy 'n' bytes from 'src' to 'dst'.
void	*ft_memcpy(void *dst, const void *src, size_t n)
{
	unsigned char	*d; // Pointer to the destination buffer.
	unsigned char	*s; // Pointer to the source buffer.

	if (!dst && !src)
		return (NULL); // Return NULL if both source and destination pointers are NULL.
	d = (unsigned char *)dst; // Cast 'dst' to an unsigned char pointer.
	s = (unsigned char *)src; // Cast 'src' to an unsigned char pointer.
	while (n--)
		*d++ = *s++; // Copy 'n' bytes from 'src' to 'dst'.
	return (dst); // Return the destination pointer.
}

// Function to concatenate two strings and update 'eol_loc' if a newline character is found.
char	*ft_strjoin_gnl(char *s1, char *s2, int *eol_loc)
{
	char	*result; // Pointer to the concatenated string.
	size_t	len1; // Length of the first string.
	size_t	len2; // Length of the second string.

	if (!s1 || !s2)
		return (NULL); // Return NULL if either of the input strings is NULL.
	len1 = ft_strlen(s1); // Calculate the length of the first string.
	len2 = ft_strlen(s2); // Calculate the length of the second string.
	result = (char *)malloc(sizeof(char) * (len1 + len2 + 1)); // Allocate memory for the concatenated string.
	if (!result)
	{
		free(s1); // Free the memory allocated for s1.
		return (NULL); // Return NULL if memory allocation fails.
	}
	ft_memcpy(result, s1, len1); // Copy the first string 's1' into the result.
	free(s1); // Free the memory allocated for s1.
	ft_memcpy(result + len1, s2, len2 + 1); // Copy the second string 's2' into the result, including the null terminator.
	if (len1 + len2 > 0 && *(result + len1 + len2 - 1) == '\n') // Check if the last character of the concatenated string is a newline.
		*eol_loc = 0; // Update 'eol_loc' to 0 (newline found).
	return (result); // Return the concatenated string.
}

// Function to copy a string from 'src' to 'dst' with a specified size limit.
void	ft_strlcpy_gnl(char *dst, const char *src, size_t dstsize)
{
	size_t	i; // Iterator variable.

	i = 0;
	if (dstsize > 0)
	{
		while (src[i] && i < dstsize - 1) // Copy characters from 'src' to 'dst' until the size limit or null terminator is reached.
		{
			dst[i] = src[i];
			i++;
		}
		dst[i] = '\0'; // Null-terminate the destination string.
	}
}
