/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_bonus.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/20 15:30:49 by wngui             #+#    #+#             */
/*   Updated: 2023/09/20 15:30:58 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line_bonus.h" // Include the header file that declares the functions and constants used in this code.

// Helper function to initialize a line from the stash buffer.
char	*init_line(char *stash, int *eol_loc)
{
	size_t	len; // Variable to store the length of the line.
	char	*line; // Variable to store the extracted line.

	len = 0;
	// Calculate the length of the line until a newline character or the end of the stash.
	while (stash[len] && stash[len] != '\n')
		len++;
	len++; // Include space for the null terminator.
	line = malloc(sizeof(char) * (len + 1)); // Allocate memory for the line.
	if (!line)
		return (NULL); // Return NULL if memory allocation fails.
	ft_memcpy(line, stash, len); // Copy the line from stash to line.
	line[len] = '\0'; // Null-terminate the line.
	// Check if the line ends with a newline character and update eol_loc accordingly.
	if (len > 0 && line[len - 1] == '\n')
		*eol_loc = len - 1;
	return (line); // Return the initialized line.
}

// Helper function to locate the position of the next end-of-line character in a line.
size_t	locate_eol(char *line)
{
	size_t	i; // Variable to iterate through the characters in the line.

	i = 0;
	if (!line)
		return (-1); // Return -1 if line is NULL.
	// Iterate through the characters in the line or up to BUFFER_SIZE.
	while (i < BUFFER_SIZE)
	{
		if (line[i] == '\n' || line[i] == '\0') // Check for newline or null terminator.
			return (i + 1); // Return the position of the newline character.
		i++;
	}
	return (i); // Return i if no newline character is found.
}

// Helper function to extract a line from the file descriptor and stash buffer.
char	*extract_line(char *line, char *stash, int *eol_loc, int fd)
{
	char	buffer[BUFFER_SIZE + 1]; // Temporary buffer to read data from the file.
	ssize_t	read_check; // Variable to store the result of the read operation.
	size_t	line_size; // Variable to store the size of the line read.

	while (*eol_loc == -1) // Continue until an end-of-line is found.
	{
		ft_bzero(buffer, (BUFFER_SIZE + 1)); // Clear the buffer.
		read_check = read(fd, buffer, BUFFER_SIZE); // Read data from the file into the buffer.
		if (read_check == -1) // Check for read errors.
		{
			free(line); // Free the allocated memory for the line.
			ft_bzero(stash, (BUFFER_SIZE + 1)); // Clear the stash buffer.
			return (NULL); // Return NULL in case of an error.
		}
		line_size = locate_eol(buffer); // Find the position of the next newline character.
		ft_strlcpy_gnl(stash, &buffer[line_size], (BUFFER_SIZE + 1)); // Copy the remaining data to the stash.
		buffer[line_size] = '\0'; // Null-terminate the extracted line.
		line = ft_strjoin_gnl(line, buffer, eol_loc); // Join the extracted line with the existing line.
		if (read_check == 0) // If the end of the file is reached.
		{
			ft_bzero(stash, BUFFER_SIZE + 1); // Clear the stash buffer.
			break; // Exit the loop.
		}
	}
	return (line); // Return the extracted line.
}

// Main function to get the next line from a file descriptor.
char	*get_next_line(int fd)
{
	static char	stash[OPEN_MAX][BUFFER_SIZE + 1]; // Static buffer to store leftover data between calls.
	char		*line; // Variable to store the extracted line.
	int			eol_loc; // Variable to store the position of the end-of-line character.

	if (fd < 0 || fd >= OPEN_MAX || BUFFER_SIZE <= 0)
		return (NULL); // Return NULL if the file descriptor is invalid or BUFFER_SIZE is non-positive.
	eol_loc = -1; // Initialize the end-of-line position.
	line = init_line(stash[fd], &eol_loc); // Initialize the line from the stash buffer.
	if (!line)
		return (NULL); // Return NULL if memory allocation fails.
	ft_strlcpy_gnl(stash[fd], &stash[fd][eol_loc + 1], BUFFER_SIZE + 1); // Update the stash buffer.
	line = extract_line(line, stash[fd], &eol_loc, fd); // Extract the complete line.
	if (!line || line[0] == '\0')
	{
		free(line); // Free the allocated memory for the line if it's empty or NULL.
		return (NULL); // Return NULL.
	}
	return (line); // Return the extracted line.
}
